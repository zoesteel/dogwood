<?php
/*-------------------------------------------------------------
    Template to display call to actions Adopt/Foster/Volunteer  
    ----------------------------------------------------------*/
?>

<div class="call-to-actions">

<a href="/volunteer"><img src="<?php bloginfo("template_url"); ?>/images/cta/volunteer.jpg" class="cta-links"/></a>
<a href="/foster"><img src="<?php bloginfo("template_url"); ?>/images/cta/foster.jpg" class="cta-links"/></a>
<a href="/adoptables"><img src="<?php bloginfo("template_url"); ?>/images/cta/adopt.jpg" class="cta-links"/></a>

</div>